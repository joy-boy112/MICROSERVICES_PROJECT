# Microservices Project with Istio and API Gateway

## Overview
This project demonstrates deploying microservices (`hello` and `goodbye`) using Kubernetes (Minikube) with an Istio service mesh and API Gateway routing.

## Project Structure
- hello-deployment.yaml
- goodbye-deployment.yaml
- hello-gateway.yaml
- README.md

## Steps Followed
- Installed Minikube and Istio
- Created microservices deployments
- Exposed microservices via Istio Ingress Gateway
- Implemented routing to `/hello` and `/goodbye`

## Architecture

```
                      [Internet/User]
                            |
                            v
                [Istio Ingress Gateway (API Gateway)]
                            |
            +---------------+----------------+
            |                                |
            v                                v
 [hello-service (Hello Deployment)]   [goodbye-service (Goodbye Deployment)]
            |                                |
         [Pod]                            [Pod]
```

## Commands Used
```bash
kubectl apply -f hello-deployment.yaml
kubectl apply -f goodbye-deployment.yaml
kubectl apply -f hello-gateway.yaml
```